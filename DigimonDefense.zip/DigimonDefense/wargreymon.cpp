#include "wargreymon.h"
static const int HP_BAR = 50;
WarGreymon::WarGreymon(QPoint pos) : QObject(0),pos(pos),pixmap(":/BattleGreymon.png")
{

}
void WarGreymon::normalAttack(){

}
void WarGreymon::draw(QPainter *painter){
    painter->save();
    QPoint healthBarPoint = pos+QPoint(-HP_BAR/2-5,pixmap.height());
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRect healthBarRect(healthBarPoint,QSize(HP_BAR,2));
    painter->drawRect(healthBarRect);
    painter->setBrush(Qt::green);
    QRect healBarLiveRect(healthBarPoint,QSize((double)Hp/max_Hp*HP_BAR,2));
    painter->drawRect(healBarLiveRect);
    QPoint toSub(-pixmap.width()/2,-pixmap.height()/2);
    painter->translate(pos);
    painter->drawPixmap(toSub,pixmap);
    painter->restore();
}
void WarGreymon::moveUpDown(int choice){
    if(choice>0){
        this->pos-=QPoint(0,20);
    }else{
        this->pos+=QPoint(0,20);
    }
}
void WarGreymon::moveLeftRight(int choice){
    if(choice>0&&this->pos.x()==700){
       this->pos -= QPoint(400,0);
    }else if(choice<0&&this->pos.x()==300){
        this->pos +=QPoint(400,0);
    }
}
