#include "chooselevelscene.h"
#include <QPainter>
#include <QDebug>
#include <QMouseEvent>
#include "gamebutton.h"
#include <QPushButton>
#include <QTimer>
ChooseLevelScene::ChooseLevelScene(QWidget *parent) : QMainWindow(parent)
{
  this->setFixedSize(800,600);
    sound = new QSound(":/ChooseLevelMusic.wav", this);
    sound->setLoops(-1);
    back_button = new GameButton(":/BackButton.png");
    back_button->setParent(this);
    back_button->move(720,500);
    scene_btn = new GameButton(":/levelone.png");
    scene_btn->setParent(this);
    scene_btn->move(20,200);
   scene_btn2 = new GameButton(":/level2button.png");
   scene_btn2->setParent(this);
   scene_btn2->move(410,410);
   scene_btn3 = new GameButton(":/Button3.png");
   scene_btn3->setParent(this);
   scene_btn3->move(400,100);

    connect(scene_btn,&QPushButton::clicked,this,[=](){
         play_scene= new PlayScene(0);
        scene_btn->zoomup();
        scene_btn->zoomdown();
        QTimer::singleShot(500,this,[=](){
            this->hide();
            sound->stop();
            play_scene->show();
            play_scene->sound->play();
        });
        connect( play_scene,&PlayScene::chooseBack,this,[=](){
            play_scene->hide();
            this->show();
            sound->play();
            play_scene->sound->stop();
//             delete  play_scene;
//            play_scene = nullptr;
        });
    });
    connect(scene_btn2,&QPushButton::clicked,this,[=](){
         play_scene= new PlayScene(1);
        scene_btn2->zoomup();
        scene_btn2->zoomdown();
        QTimer::singleShot(500,this,[=](){
            this->hide();
            sound->stop();
            play_scene->show();
            play_scene->sound->play();
        });
        connect( play_scene,&PlayScene::chooseBack,this,[=](){
            play_scene->hide();
            this->show();
            sound->play();
            play_scene->sound->stop();
//             delete  play_scene;
//            play_scene = nullptr;
        });
    });
    connect(scene_btn3, &QPushButton::clicked,this,[=](){
        rpg = new RPGScene;
        scene_btn3->zoomup();
        scene_btn3->zoomdown();
        QTimer::singleShot(500,this,[=](){
            this->hide();
            sound->stop();
            rpg->show();
            rpg->bgsound->play();
        });
    });
    connect(back_button,&QPushButton::clicked,this,[=](){
        emit chooseSceneBack();
        sound->stop();
    });
}
void ChooseLevelScene::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix(":/DigimonWorldMap.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pix);

}
void ChooseLevelScene::mousePressEvent(QMouseEvent *e){
    qDebug()<<"x = "<<e->x()<<"y = "<<e->y();
}
