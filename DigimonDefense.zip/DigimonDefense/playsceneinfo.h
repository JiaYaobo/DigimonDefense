#ifndef PLAYSCENEINFO_H
#define PLAYSCENEINFO_H

#include <QObject>
#include <QPoint>
#include <QMap>
#include <QVector>
class PlaySceneInfo : public QObject
{
    Q_OBJECT
public:
     PlaySceneInfo(int chooseWhich);
      QVector<QString> scene_picture;
      QVector<QPoint> SSJH_pos;
      QVector<QPoint>digimon_pos;
      QVector<QPoint>devilmon_way;
      QMap<QString, QVector<int>>scene_num;
      QVector<QVector<int>> waveNumInfo;
      QVector<QVector<int>>waveTimeInfo;
      int waves;
      int choice;
      void  loadLevel1Info();
      void loadLevel2Info();
signals:

};

#endif // PLAYSCENEINFO_H
