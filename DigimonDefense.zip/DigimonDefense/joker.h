#ifndef JOKER_H
#define JOKER_H

#include <QObject>
#include <QPainter>
#include <QPoint>
#include <QPropertyAnimation>
class Joker : public QObject
{
    Q_OBJECT
public:
     Joker(QPoint pos);
     void draw(QPainter* painter);
     int max_blood = 10;
     int blood = 10;
private:
     QPoint pos;
     QPixmap pixmap;


signals:

};

#endif // JOKER_H
