#include "weapon.h"
#include <QVector2D>
#include <QtMath>
Weapon::Weapon(QString fileName, QPoint start, QPoint end) : QObject(0),pixmap(fileName)
{
  this->start = start;
  this->current = start;
   this->end = end;
}
void Weapon::draw(QPainter *painter){
    painter->drawPixmap(current, pixmap);
}
void Weapon::move(){
    if(qAbs(current.x()-end.x())<=1){
        this->isHere =true;
        return;
    }
    QPoint target = end;
    qreal moveSpeed = 2;
    QVector2D normalized(target - current);
    normalized.normalize();
    current= current + normalized.toPoint()*moveSpeed;
}
