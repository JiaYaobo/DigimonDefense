#ifndef WARGREYMON_H
#define WARGREYMON_H

#include <QObject>
#include <QPainter>
#include <QPoint>
#include <QPropertyAnimation>
class WarGreymon : public QObject
{
    Q_OBJECT
public:
   WarGreymon(QPoint pos);
   void normalAttack();
   void draw(QPainter *painter);
   void moveLeftRight(int choice);
   void moveUpDown(int choice);
   bool isInvincible = false;
   int max_Hp = 100;
   int Hp = 100;
   QPoint pos;
   QPixmap pixmap;

signals:

};

#endif // WARGREYMON_H
