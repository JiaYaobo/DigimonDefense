#include "joker.h"
static const int HP_BAR = 50;
Joker::Joker(QPoint pos) : QObject(0),pos(pos),pixmap(":/Joker.png")
{

}
void Joker::draw(QPainter *painter){
    painter->save();
    QPoint healthBarPoint = pos+QPoint(-HP_BAR/2-5,pixmap.height());
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRect healthBarRect(healthBarPoint,QSize(HP_BAR,4));
    painter->drawRect(healthBarRect);
    painter->setBrush(Qt::green);
    QRect healBarLiveRect(healthBarPoint,QSize((double)blood/max_blood*HP_BAR,4));
    painter->drawRect(healBarLiveRect);
    QPoint toSub(-pixmap.width()/2,-pixmap.height()/2);
    painter->translate(pos);
        painter->drawPixmap(toSub, pixmap);
    painter->restore();
}
