#ifndef DEVILMONINFO_H
#define DEVILMONINFO_H

#include <QObject>
#include <QVector>
#include <QPoint>
#include <QMap>
class DevilmonInfo : public QObject
{
    Q_OBJECT
public:
 DevilmonInfo(int chooseWho);
  int choice;
  QVector<QString>devilmon_images;
  QMap<QString, qreal>devilmon_ability;
  int damage;
  void loadSmallDevilmonInfo();
  void loadDevilmonInfo();
  void loadSuperDevilmonInfo();
signals:

};

#endif // DEVILMONINFO_H
