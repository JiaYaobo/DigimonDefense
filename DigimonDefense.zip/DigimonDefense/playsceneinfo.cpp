#include "playsceneinfo.h"

PlaySceneInfo::PlaySceneInfo(int chooseWhich) : QObject(0)
{
    choice = chooseWhich;
   scene_picture.push_back(":/Level2.jpeg");
   scene_picture.push_back(":/Level3.jpeg");
   if(chooseWhich==0){
       loadLevel1Info();
   }else{
       loadLevel2Info();
   }
}
void PlaySceneInfo::loadLevel1Info(){
    waves =3;
    SSJH_pos.push_back(QPoint(650,260));
    SSJH_pos.push_back(QPoint(445,260));
    SSJH_pos.push_back(QPoint(580,60));
    SSJH_pos.push_back(QPoint(305,60));
    SSJH_pos.push_back(QPoint(190,330));
    SSJH_pos.push_back(QPoint(220,120));
    SSJH_pos.push_back(QPoint(305,320));
    digimon_pos.push_back(QPoint(650,220));
    digimon_pos.push_back(QPoint(445,220));
    digimon_pos.push_back(QPoint(580,85));
    digimon_pos.push_back(QPoint(305,85));
    digimon_pos.push_back(QPoint(190,290));
    digimon_pos.push_back(QPoint(220,145));
    digimon_pos.push_back(QPoint(305,280));
    devilmon_way.push_back(QPoint(755,245));
    devilmon_way.push_back(QPoint(720,245));
   devilmon_way.push_back(QPoint(720,160));
    devilmon_way.push_back(QPoint(325, 160));
    devilmon_way.push_back(QPoint(325,240));
   devilmon_way.push_back(QPoint(111,235));
   devilmon_way.push_back(QPoint(111,33));
   waveNumInfo={{0, 0, 0,0,0},{0,0,1,1,1},{1,1,1,1,1}};
   waveTimeInfo={{1000,6000,11000,16000,19000},{1000,6000,11000,16000,19000},{1000,6000,11000,16000,19000}};
}
void PlaySceneInfo::loadLevel2Info(){
    waves =3;
    SSJH_pos.push_back(QPoint(680,85));
    SSJH_pos.push_back(QPoint(490,150));
    SSJH_pos.push_back(QPoint(570,340));
    SSJH_pos.push_back(QPoint(340,265));
    SSJH_pos.push_back(QPoint(150,280));
    digimon_pos.push_back(QPoint(630,85));
    digimon_pos.push_back(QPoint(490,110));
    digimon_pos.push_back(QPoint(570,300));
    digimon_pos.push_back(QPoint(375,265));
    digimon_pos.push_back(QPoint(150,240));
    devilmon_way.push_back(QPoint(694,258));
    devilmon_way.push_back(QPoint(576,255));
   devilmon_way.push_back(QPoint(567,72));
    devilmon_way.push_back(QPoint(410,62));
    devilmon_way.push_back(QPoint(408,135));
   devilmon_way.push_back(QPoint(239,143));
   devilmon_way.push_back(QPoint(237,227));
   devilmon_way.push_back(QPoint(451,231));
   devilmon_way.push_back(QPoint(453,335));
   devilmon_way.push_back(QPoint(78,342));
   devilmon_way.push_back(QPoint(81,66));
   waveNumInfo={{0, 1, 1,1,1},{0,1,1,1,2},{2,2,2,2,2}};
   waveTimeInfo={{1000,6000,11000,16000,19000},{1000,6000,11000,16000,19000},{1000,6000,11000,16000,19000}};
}
