#include "rpgscene.h"
#include <QDebug>
#include<QTimer>
#include <QtMath>
#include "weapon.h"
#include <QLabel>
#include <QMovie>
int RPGScene::count =0;
RPGScene::RPGScene(QWidget *parent) : QMainWindow(parent)
{
   label = new QLabel(this);
   movie = new QMovie(":/agumonevolution.gif");
    sound = new QSound(":/Winm.wav",this);
    bgsound = new QSound(":/RPGMusic.wav",this);
    bgsound->setLoops(-1);
    this->setFixedSize(800,600);
    evolutionAnimation();
   agumon = new WarGreymon(QPoint(700,300));
   joker = new Joker(QPoint(50,250));
   QTimer * timer = new QTimer(this);
   QTimer * timer2 = new QTimer(this);
   QTimer::singleShot(20100,this,[=](){
       connect(timer, &QTimer::timeout, this,&RPGScene::attackAgumon);
       timer->start(3000);
       connect(timer2,&QTimer::timeout, this,&RPGScene::updateMap);
       timer2->start(10);
   });
}
void RPGScene::paintEvent(QPaintEvent *){
    if(!win){
    QPainter painter(this);
    painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(":/RPGpixmap.jpeg"));
    this->agumon->draw(&painter);
    this->joker->draw(&painter);
    foreach(Weapon * weapon, agumon_weapon){
        weapon->draw(&painter);
    }
    foreach(Weapon * weapon, joker_weapon){
        weapon->draw(&painter);
    }}else{
        QPainter painter(this);
        painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(":/Win.png"));
    }
}
void RPGScene::keyPressEvent(QKeyEvent *e){

if(e->key() == Qt::Key_W){
    agumon->moveUpDown(1);
    update();
}else if(e->key() ==Qt::Key_S){
    agumon->moveUpDown(-1);
    update();
}else if(e->key() == Qt::Key_I){
    agumon->moveLeftRight(1);
    update();
}else if(e->key() == Qt::Key_L){
    agumon->moveLeftRight(-1);
    update();
}
if(e->key() == Qt::Key_J){
    agumon->normalAttack();
    attackJoker();
    update();
}
}
void RPGScene::mousePressEvent(QMouseEvent *e){
   qDebug()<<e->x()<<","<<e->y();
}
void RPGScene::attackAgumon(){
    count++;
     if(count%2 == 0){
         attackModel1();
     }else{
         attackModel2();
     }
}
void RPGScene::attackModel1(){
      Weapon * sword1= new Weapon(":/sword.png",QPoint(100,150),QPoint(700,150));
      Weapon * sword2 = new Weapon(":/sword.png",QPoint(100,250),QPoint(700,250));
      Weapon * sword3 = new Weapon(":/sword.png",QPoint(100,350),QPoint(700,350));
      joker_weapon.push_back(sword1);
      joker_weapon.push_back(sword2);
      joker_weapon.push_back(sword3);
}
void RPGScene::attackModel2(){
    Weapon * sword1= new Weapon(":/sword.png",QPoint(100,100),QPoint(700,500));
    Weapon * sword2 = new Weapon(":/sword.png",QPoint(100,200),QPoint(700,400));
    Weapon * sword3 = new Weapon(":/sword.png",QPoint(100,300),QPoint(700,300));
    Weapon * sword4= new Weapon(":/sword.png",QPoint(100,400),QPoint(700,200));
    Weapon * sword5 = new Weapon(":/sword.png",QPoint(100,500),QPoint(700,100));
    joker_weapon.push_back(sword1);
      joker_weapon.push_back(sword2);
        joker_weapon.push_back(sword3);
        joker_weapon.push_back(sword4);
        joker_weapon.push_back(sword5);
}
void RPGScene::attackJoker(){
    Weapon * fire = new Weapon(":/fire.png",agumon->pos, agumon->pos-QPoint(200,0));
    agumon_weapon.push_back(fire);
    if(agumon->pos.x()==300&&agumon->pos.y()<=325&&agumon->pos.y()>=200){
        QTimer::singleShot(2000,this,[=](){
           joker->blood-=1;
        });
    }
}
void RPGScene::updateMap(){
    judgeWin();
    foreach(Weapon * weapon, agumon_weapon){
        if(weapon->isHere==false){
        weapon->move();
        update();
        }else{
            agumon_weapon.removeOne(weapon);
            delete  weapon;
            update();
        }
    }
    foreach(Weapon * weapon, joker_weapon){
        if(!weapon->isHere){
            weapon->move();
            if(qAbs(weapon->current.y()-agumon->pos.y())<=20&&agumon->pos.x()-weapon->current.x()<=60
                    &&agumon->pos.x()-weapon->current.x()>0&&weapon->isAttacked==false){
                agumon->Hp -=10;
                weapon->isAttacked = true;
            }
            update();
        }else{
            joker_weapon.removeOne(weapon);
            delete weapon;
            update();
        }
    }

}
void RPGScene::judgeWin(){
    if(joker->blood<=0){
        this->win = true;
        update();
    }
    if(!ifPlay&&win){
        playWinMusic();
    }
}
void RPGScene::playWinMusic(){

//    bgsound->play();
    sound->play();
    ifPlay =true;
}
void RPGScene::evolutionAnimation(){
    label->setFixedSize(this->width(),this->height());
    movie->setScaledSize(label->size());
    label->setMovie(movie);
    movie->start();
    QTimer::singleShot(19000,this,[=](){
        movie->stop();
        delete  movie;
        delete label;
    });
}
