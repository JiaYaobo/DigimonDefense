#include "devilmoninfo.h"

DevilmonInfo::DevilmonInfo(int chooseWho) : QObject(0)
{
    devilmon_images.push_back(":/SmallDevilMon.png");
    devilmon_images.push_back(":/Devilmon.png");
    devilmon_images.push_back(":/SuperDevilmon.png");
    choice = chooseWho;
   if(chooseWho == 0){
       loadSmallDevilmonInfo();
   }else if(chooseWho ==1){
       loadDevilmonInfo();
   }
   else{
       loadSuperDevilmonInfo();
   }
}
void DevilmonInfo::loadSmallDevilmonInfo(){
    damage = 1;
    devilmon_ability["HP"] = 80;
    devilmon_ability["SPEED"] = 1.0;
}
void DevilmonInfo::loadDevilmonInfo(){
    damage = 3;
    devilmon_ability["HP"] = 150;
    devilmon_ability["SPEED"] = 2.0;
}
void DevilmonInfo::loadSuperDevilmonInfo(){
    damage =5;
    devilmon_ability["HP"] = 210;
    devilmon_ability["SPEED"] = 1.5;
}
