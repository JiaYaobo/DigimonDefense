#ifndef RPGSCENE_H
#define RPGSCENE_H

#include <QMainWindow>
#include <QPainter>
#include <QPoint>
#include <QPaintEvent>
#include <QEvent>
#include "wargreymon.h"
#include "joker.h"
#include "weapon.h"
#include <QSound>
#include <QLabel>
#include <QMovie>
class RPGScene : public QMainWindow
{
    Q_OBJECT
public:
    RPGScene(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);
    void mousePressEvent(QMouseEvent*e);
    void keyPressEvent(QKeyEvent* e);
    void attackAgumon();
    void attackJoker();
    void attackModel1();
    void attackModel2();
    void updateMap();
    void judgeWin();
    void playWinMusic();
    void evolutionAnimation();
    bool win = false;
    bool ifPlay = false;
    QLabel * label;
    QMovie * movie;
    QSound * sound = nullptr;
    QSound * bgsound =nullptr;
   QList<Weapon*>agumon_weapon;
   QList<Weapon*>joker_weapon;
   WarGreymon * agumon= nullptr ;
   Joker * joker = nullptr;
   static int count ;
signals:

};

#endif // RPGSCENE_H
