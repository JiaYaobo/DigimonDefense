#ifndef CHOOSELEVELSCENE_H
#define CHOOSELEVELSCENE_H

#include <QMainWindow>
#include "gamebutton.h"
#include "playscene.h"
#include "rpgscene.h"
#include <QSound>
class ChooseLevelScene : public QMainWindow
{
    Q_OBJECT
public:
    explicit ChooseLevelScene(QWidget *parent = nullptr);
   virtual void paintEvent(QPaintEvent*);
    virtual void mousePressEvent(QMouseEvent *e);
        QSound * sound;
private:
    GameButton* back_button = nullptr;
    GameButton * scene_btn = nullptr;
    GameButton * scene_btn2 = nullptr;
    GameButton * scene_btn3 = nullptr;
    PlayScene * play_scene = nullptr;
    RPGScene * rpg = nullptr;
signals:
  void chooseSceneBack();
};

#endif // CHOOSELEVELSCENE_H
