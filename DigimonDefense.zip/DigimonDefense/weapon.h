#ifndef WEAPON_H
#define WEAPON_H

#include <QObject>
#include <QPainter>

class Weapon : public QObject
{
    Q_OBJECT
public:
  Weapon(QString fileName, QPoint start, QPoint end);
  void move();
  void draw(QPainter * painter);
  QPoint start;
  QPoint current;
  QPoint end;
  QPixmap pixmap;
  bool isHere= false;
  bool isAttacked = false;
signals:

};

#endif // WEAPON_H
